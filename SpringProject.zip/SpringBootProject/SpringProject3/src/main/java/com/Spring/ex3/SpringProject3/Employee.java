package com.Spring.ex3.SpringProject3;

public class Employee 
{
	int Empid;
	String name;
	float salary;
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Employee(int empid, String name, float salary) {
		super();
		Empid = empid;
		this.name = name;
		this.salary = salary;
	}
	public int getEmpid() {
		return Empid;
	}
	public void setEmpid(int empid) {
		Empid = empid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public float getSalary() {
		return salary;
	}
	public void setSalary(float salary) {
		this.salary = salary;
	}
	@Override
	public String toString() {
		return "Employee [Empid=" + Empid + ", name=" + name + ", salary=" + salary + "]";
	}
	
	

}
