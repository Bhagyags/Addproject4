package com.Spring.Ex7.SpringProject7;

public class Car 
{
	Driver dr1;

	public Car() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Car(Driver dr1) {
		super();
		this.dr1 = dr1;
	}

	public Driver getDr1() {
		return dr1;
	}

	public void setDr1(Driver dr1) {
		this.dr1 = dr1;
	}

	@Override
	public String toString() {
		return "Car [dr1=" + dr1 + "]";
	}
	
		
}
