package com.Spring.Ex7.SpringProject7;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App 
{
    public static void main( String[] args )
    {
    	ClassPathXmlApplicationContext cfg=new ClassPathXmlApplicationContext("config.xml");
    	Car c=(Car)cfg.getBean("car");
    	
    	System.out.println(c);
    	University u=(University)cfg.getBean("uni1");
    	System.out.println(u);
    	
    	
    }
}
