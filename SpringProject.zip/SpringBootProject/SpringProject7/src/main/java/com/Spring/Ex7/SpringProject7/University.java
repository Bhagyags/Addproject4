package com.Spring.Ex7.SpringProject7;

public class University 
{
	Professor ps1;

	public University() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "University [ps1=" + ps1 + "]";
	}

	public University(Professor ps1) {
		super();
		this.ps1 = ps1;
	}

	public Professor getPs1() {
		return ps1;
	}

	public void setPs1(Professor ps1) {
		this.ps1 = ps1;
	}
	
	
}
