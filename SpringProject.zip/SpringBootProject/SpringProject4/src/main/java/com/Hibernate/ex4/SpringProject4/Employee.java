package com.Hibernate.ex4.SpringProject4;

import java.util.List;
import java.util.Map;
import java.util.Set;

public class Employee 
{
	List<String> technologies;
	Set <String> Projects;
	Map<String,String>company;
	public Employee(List<String> technologies, Set<String> projects, Map<String, String> company) {
		super();
		this.technologies = technologies;
		Projects = projects;
		this.company = company;
	}
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	public List<String> getTechnologies() {
		return technologies;
	}
	public void setTechnologies(List<String> technologies) {
		this.technologies = technologies;
	}
	public Set<String> getProjects() {
		return Projects;
	}
	public void setProjects(Set<String> projects) {
		Projects = projects;
	}
	public Map<String, String> getCompany() {
		return company;
	}
	public void setCompany(Map<String, String> company) {
		this.company = company;
	}
	@Override
	public String toString() {
		return "Employee [technologies=" + technologies + ", Projects=" + Projects + ", company=" + company + "]";
	}
	
	

}
