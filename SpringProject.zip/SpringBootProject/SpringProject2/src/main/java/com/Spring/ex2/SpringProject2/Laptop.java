package com.Spring.ex2.SpringProject2;

public class Laptop 
{
	int serialNo;
	String brand;
	int price;
	
	public Laptop() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Laptop(int serialNo, String brand, int price) {
		super();
		this.serialNo = serialNo;
		this.brand = brand;
		this.price = price;
	}

	public int getSerialNo() {
		return serialNo;
	}

	public void setSerialNo(int serialNo) {
		this.serialNo = serialNo;
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	@Override
	public String toString() {
		return "Laptop [serialNo=" + serialNo + ", brand=" + brand + ", price=" + price + "]";
	}
	
	

}
