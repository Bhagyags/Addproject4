package com.Spring.ex2.SpringProject2;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App 
{
    public static void main( String[] args )
    {
    	ClassPathXmlApplicationContext ctx=new ClassPathXmlApplicationContext("config.xml");
        Laptop s1=(Laptop)ctx.getBean("lp1");
        Laptop s2=(Laptop)ctx.getBean("lp2");
        Laptop s3=(Laptop)ctx.getBean("lp3");
        Laptop s4=(Laptop)ctx.getBean("lp4");
        System.out.println(s1);
        System.out.println(s2);	
        System.out.println(s3);
        System.out.println(s4);
    }
}
