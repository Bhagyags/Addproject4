package com.Hibernate.ex5.SpringProject5;

public class KodnestClasses 
{
	@Override
	public String toString() {
		return "KodnestClasses [tr=" + tr + "]";
	}

	Trainer tr;

	public KodnestClasses() {
		super();
		// TODO Auto-generated constructor stub
	}

	public KodnestClasses(Trainer tr) {
		super();
		this.tr = tr;
	}

	public Trainer getTr() {
		return tr;
	}

	public void setTr(Trainer tr) {
		this.tr = tr;
	}
	
	

}
