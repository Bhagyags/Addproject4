package com.Hibernate.ex5.SpringProject5;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App 
{
    public static void main( String[] args )
    {
        ClassPathXmlApplicationContext ctx=new ClassPathXmlApplicationContext("config.xml");
        Trainer tr=(Trainer)ctx.getBean("tr1");
        System.out.println(tr);
        
        
        KodnestClasses kc=(KodnestClasses) ctx.getBean("kd1");
        System.out.println(kc);
    }
}
