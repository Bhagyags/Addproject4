package com.Hibernate.ex5.SpringProject5;

public class Trainer 
{
	int t_id;
	String name;
	public Trainer() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Trainer(int t_id, String name) {
		super();
		this.t_id = t_id;
		this.name = name;
	}
	public int getT_id() {
		return t_id;
	}
	public void setT_id(int t_id) {
		this.t_id = t_id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Override
	public String toString() {
		return "Trainer [t_id=" + t_id + ", name=" + name + "]";
	}
	
	

}
